var app = angular.module('myApp', []);

app.controller('myLoadFileTable', function ($scope, $http) {
  var links = window.location.href.split("?");
  var params = links[1].split("&");
  var doc_id = params[1].split("=")[1];
  $http.post('http://localhost:8681/actions/file/one',
    JSON.stringify({
      "Id": doc_id,
    }), { 'Content-Type': 'multipart/form-data' }).then(function successCallback(response) {
      console.log(response.data);
      data = JSON.parse(response.data);
      $scope.file_name = data.fileName;
      $scope.file_locator = data.fileLocator;
      $scope.username = data.userName;
      $scope.user_id = data.userID;  
      $scope.file_id = data.id;
    }, function errorCallback(response) {
      // 请求失败执行代码
      alert("add failed");
      return;
    });


  $scope.returnindex = function () {
    window.location.assign('./index.html');
  }
});
