var app = angular.module('myApp', []);

app.controller('myLoadFileTable', function ($scope, $http) {
    $scope.username = sessionStorage.getItem("loadFileSystemUserName");
    $scope.user_id = sessionStorage.getItem("loadFileSystemUserID");
    if ($scope.user_id == '' || $scope.user_id == null || $scope.user_id == undefined) {
      window.location.href = './login.html';
    }
    var links = window.location.href.split("?");
    var params = links[1].split("&");
    var doc_id = params[1].split("=")[1];
    console.log(doc_id);
    $http.post('http://localhost:8681/actions/file/one',
    JSON.stringify({
      "Id": doc_id,
    }), { 'Content-Type': 'multipart/form-data' }).then(function successCallback(response) {
      console.log(response.data);
      data = JSON.parse(response.data);
      $scope.file_name = data.fileName;
      $scope.file_locator = data.fileLocator;
      $scope.file_id = data.id;
    }, function errorCallback(response) {
      // 请求失败执行代码
      alert("add failed");
      return;
    });
  $scope.loadfile = function () {
    if ($scope.file_name == '') {
      alert("please input valid information!")
      return;
    }
    var form = new FormData();
    console.log(document.getElementById("fileUpload"));
    var file = document.getElementById("fileUpload").files[0];
    form.append('file', file);
    console.log(form);
    $http.post('http://localhost:8681/actions/file/add',
      JSON.stringify({
        "userName": $scope.username,
        "userID": $scope.user_id,
        "FileName": $scope.file_name,
        "File": file,
        "FileLocator": $scope.file_locator,
        "FileID": $scope.file_id
      }), { 'Content-Type': 'multipart/form-data' }).then(function successCallback(response) {
        if (response.data.result.isSuccess == true) {
          alert("Success!");
          window.location.assign('./index.html');
        }
      }, function errorCallback(response) {
        // 请求失败执行代码
        alert("add failed");
        return;
      });
  }
});
