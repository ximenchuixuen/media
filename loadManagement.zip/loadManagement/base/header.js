var app = angular.module('myApp', []);
app.controller('myHeader', function ($scope) {
  username = sessionStorage.getItem("loadFileSystemUserName");
  console.log(username);
  console.log(username == null || username == "");
  if (username == null || username == "") {
    $scope.userName = "tourist";
    $scope.loginkey = "Login";
  }else{
    $scope.userName = username;
    $scope.loginkey = "LoginOut";
  }
  console.log($scope.userName);
  $scope.login = function () {
    console.log($scope.userName);
    console.log($scope.userName == "tourist");
    if ($scope.userName == "tourist") {
      parent.location.assign("http://localhost:8681/login.html");
       return;
    }else{
        sessionStorage.removeItem("loadFileSystemUserName");
        sessionStorage.removeItem("loadFileSystemUserID");
        parent.location.reload();
    }
  }
  $scope.index = function () {
    parent.location.assign("http://localhost:8681/index.html");
  }
});

