var app = angular.module('myApp', []);
app.controller('myFileTable', function ($scope, $http) {
  $scope.username = sessionStorage.getItem("loadFileSystemUserName");
  $scope.user_id = sessionStorage.getItem("loadFileSystemUserID");
  $scope.PageNow = 1;
  $http({
    method: 'GET',
    url: 'http://localhost:8681/actions/file/list'
  }).then(function successCallback(response) {
    var alldata = JSON.parse(response.data.result);
    console.log(alldata);
    $scope.alldata = alldata;
    $scope.files = alldata.slice(0,10);
    $scope.totalnum = alldata.length;
    $scope.totalpage = Math.ceil(alldata.length / 10);
    console.log($scope.totalnum);
    console.log($scope.totalpage);
  }, function errorCallback(response) {
    // 请求失败执行代码
  });
  
  $scope.delete = function (id) {
    $scope.username = sessionStorage.getItem("loadFileSystemUserName");
    $scope.user_id = sessionStorage.getItem("loadFileSystemUserID");
   if ($scope.user_id==''||$scope.user_id==null||$scope.user_id==undefined){
     window.location.href = './login.html';
   }
    $http.post('http://localhost:8681/actions/file/delete',
    JSON.stringify({
      "Id": id,
    }), { 'Content-Type': 'application/json;charset=UTF-8' }).then(function successCallback(response) {
      res = response.data;
      if (res.isSuccess == true) {
        alert("delete success");
        window.location.reload();
      }
    }, function errorCallback(response) {
      // 请求失败执行代码
      alert("invalid username or password");
      return;
    });
  }
  $scope.details = function (id) {
    $scope.username = sessionStorage.getItem("loadFileSystemUserName");
    $scope.user_id = sessionStorage.getItem("loadFileSystemUserID");
   if ($scope.user_id==''||$scope.user_id==null||$scope.user_id==undefined){
     window.location.href = './login.html';
   }
    window.location.assign("http://localhost:8681/detail.html?type=modify&id=" + id);
  }

  $scope.edit = function (id) {
    $scope.username = sessionStorage.getItem("loadFileSystemUserName");
    $scope.user_id = sessionStorage.getItem("loadFileSystemUserID");
   if ($scope.user_id==''||$scope.user_id==null||$scope.user_id==undefined){
     window.location.href = './login.html';
   }
    window.location.assign("http://localhost:8681/editfile.html?type=modify&id=" + id);
  }

  $scope.previous = function () {
    if ($scope.PageNow==1){
      alert("this is the first page!")
    }
    $scope.PageNow--
    $scope.files = $scope.alldata.slice(($scope.PageNow-1)*10,($scope.PageNow)*10-1);
  }
  $scope.next = function () {
    if ($scope.PageNow==$scope.totalpage){
      alert("this is the last page!")
    }
    $scope.PageNow++
    $scope.files = $scope.alldata.slice(($scope.PageNow-1)*10,($scope.PageNow)*10-1);
  }
});
