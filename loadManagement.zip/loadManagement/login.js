var app = angular.module('myApp', []);
app.controller('personCtrl', function ($scope, $http) {
  $scope.username = "";
  $scope.password = "";
  $scope.login = function () {
    $http.post('http://localhost:8681/actions/login',
      JSON.stringify({
        "username": $scope.username,
        "password": $scope.password,
      }), { 'Content-Type': 'application/json;charset=UTF-8' }).then(function successCallback(response) {
        console.log(response);
        res = response.data.result;
        console.log(res);
        if (res.user_id != "") {
          sessionStorage.setItem('loadFileSystemUserName', $scope.username);
          sessionStorage.setItem('loadFileSystemUserID', res.user_id);
          alert("Login success");
          window.location.assign("./index.html");
        }
      }, function errorCallback(response) {
        // 请求失败执行代码
        alert("invalid username or password");
        return;
      });
  }
});

