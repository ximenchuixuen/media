var app = angular.module('myApp', []);

app.controller('myLoadFileTable', function ($scope, $http) {
    $scope.username = sessionStorage.getItem("loadFileSystemUserName");
    $scope.user_id = sessionStorage.getItem("loadFileSystemUserID");
    if ($scope.user_id == '' || $scope.user_id == null || $scope.user_id == undefined) {
      window.location.href = './login.html';
    }

  $scope.loadfile = function () {
    if ($scope.file_name == '') {
      alert("please input valid information!")
      return;
    }
    var form = new FormData();
    console.log(document.getElementById("fileUpload"));
    var file = document.getElementById("fileUpload").files[0];
    form.append('file', file);
    console.log(form);
    $http.post('http://localhost:8681/actions/file/add',
      JSON.stringify({
        "userName": $scope.username,
        "userID": $scope.user_id,
        "FileName": $scope.file_name,
        "File": file,
      }), { 'Content-Type': 'multipart/form-data' }).then(function successCallback(response) {
        if (response.data.result.isSuccess == true) {
          alert("Success!");
          window.location.assign('./index.html');
        }
      }, function errorCallback(response) {
        // 请求失败执行代码
        alert("add failed");
        return;
      });
  }
});
